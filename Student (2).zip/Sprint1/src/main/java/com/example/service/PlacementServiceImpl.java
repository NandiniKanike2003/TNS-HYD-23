package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.entity.Placement;
import com.example.repository.PlacementRepository;

public class PlacementServiceImpl implements PlacementService{
	@Autowired
    PlacementRepository repository;

	@Override
	public Placement savePlacement(Placement placement) {
		// TODO Auto-generated method stub
		return repository.save(placement);
	}

	@Override
	public List<Placement> fetchPlacementList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Placement fetchPlacementById(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public void deletePlacementById(Long id) {
		// TODO Auto-generated method stub
		
		 repository.deleteById(id);
		
	}
	
	
	

}
